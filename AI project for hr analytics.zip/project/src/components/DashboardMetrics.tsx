import React from 'react';
import { DashboardMetrics as Metrics } from '../types';

interface Props {
  metrics: Metrics;
}

const DashboardMetrics: React.FC<Props> = ({ metrics }) => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
      <div className="bg-white p-6 rounded-lg shadow-md">
        <h3 className="text-gray-500 text-sm">Total Employees</h3>
        <p className="text-2xl font-bold">{metrics.totalEmployees}</p>
      </div>
      <div className="bg-white p-6 rounded-lg shadow-md">
        <h3 className="text-gray-500 text-sm">Attrition Rate</h3>
        <p className="text-2xl font-bold">{metrics.attritionRate.toFixed(2)}%</p>
      </div>
      <div className="bg-white p-6 rounded-lg shadow-md">
        <h3 className="text-gray-500 text-sm">Average Monthly Income</h3>
        <p className="text-2xl font-bold">${metrics.averageIncome.toFixed(2)}</p>
      </div>
    </div>
  );
};

export default DashboardMetrics;