import React from 'react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell
} from 'recharts';
import { Employee, ChartData, AttritionData } from '../types';

interface Props {
  employees: Employee[];
}

const COLORS = ['#4F46E5', '#EF4444', '#10B981', '#F59E0B'];

const DashboardCharts: React.FC<Props> = ({ employees }) => {
  const attritionData: ChartData[] = [
    {
      name: 'Retained',
      value: employees.filter(emp => !emp.attrition).length
    },
    {
      name: 'Attrited',
      value: employees.filter(emp => emp.attrition).length
    }
  ];

  const departmentAttrition: AttritionData[] = Array.from(
    new Set(employees.map(emp => emp.department))
  ).map(dept => ({
    name: dept,
    retained: employees.filter(emp => emp.department === dept && !emp.attrition).length,
    attrited: employees.filter(emp => emp.department === dept && emp.attrition).length
  }));

  const ageGroups = Array.from({ length: 5 }, (_, i) => ({
    name: `${20 + i * 10}-${29 + i * 10}`,
    retained: employees.filter(
      emp => emp.age >= 20 + i * 10 && emp.age < 30 + i * 10 && !emp.attrition
    ).length,
    attrited: employees.filter(
      emp => emp.age >= 20 + i * 10 && emp.age < 30 + i * 10 && emp.attrition
    ).length
  }));

  const salaryByRole = Array.from(
    new Set(employees.map(emp => emp.jobRole))
  ).map(role => ({
    name: role,
    salary: employees
      .filter(emp => emp.jobRole === role)
      .reduce((acc, emp) => acc + emp.monthlyIncome, 0) /
      employees.filter(emp => emp.jobRole === role).length
  }));

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
      <div className="bg-white p-6 rounded-lg shadow-md">
        <h2 className="text-xl font-semibold mb-4">Attrition Distribution</h2>
        <div className="h-80">
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie
                data={attritionData}
                dataKey="value"
                nameKey="name"
                cx="50%"
                cy="50%"
                outerRadius={80}
                label
              >
                {attritionData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip />
              <Legend />
            </PieChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="bg-white p-6 rounded-lg shadow-md">
        <h2 className="text-xl font-semibold mb-4">Department-wise Attrition</h2>
        <div className="h-80">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={departmentAttrition}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Bar dataKey="retained" name="Retained" fill="#4F46E5" />
              <Bar dataKey="attrited" name="Attrited" fill="#EF4444" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="bg-white p-6 rounded-lg shadow-md">
        <h2 className="text-xl font-semibold mb-4">Monthly Income by Job Role</h2>
        <div className="h-80">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={salaryByRole}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" angle={-45} textAnchor="end" height={100} />
              <YAxis />
              <Tooltip />
              <Line type="monotone" dataKey="salary" stroke="#4F46E5" />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="bg-white p-6 rounded-lg shadow-md">
        <h2 className="text-xl font-semibold mb-4">Age Distribution by Attrition</h2>
        <div className="h-80">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={ageGroups}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Bar dataKey="retained" name="Retained" fill="#4F46E5" />
              <Bar dataKey="attrited" name="Attrited" fill="#EF4444" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
};

export default DashboardCharts;