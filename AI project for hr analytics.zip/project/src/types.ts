export interface Employee {
  id: string;
  age: number;
  attrition: boolean;
  department: string;
  gender: string;
  jobRole: string;
  monthlyIncome: number;
  yearsAtCompany: number;
  businessTravel: string;
  education: number;
  educationField: string;
  jobLevel: number;
  maritalStatus: string;
  numCompaniesWorked: number;
  performanceRating: number;
  totalWorkingYears: number;
  trainingTimesLastYear: number;
  workLifeBalance: number;
  yearsInCurrentRole: number;
  yearsSinceLastPromotion: number;
}

export interface DashboardMetrics {
  totalEmployees: number;
  attritionRate: number;
  averageIncome: number;
}

export interface ChartData {
  name: string;
  value: number;
}

export interface AttritionData {
  name: string;
  retained: number;
  attrited: number;
}