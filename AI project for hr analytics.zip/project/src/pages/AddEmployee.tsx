import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Employee } from '../types';
import {
  departments,
  jobRoles,
  educationFields,
  businessTravelOptions,
  maritalStatusOptions
} from '../data/sampleData';

const AddEmployee = () => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    age: '',
    department: '',
    gender: '',
    jobRole: '',
    monthlyIncome: '',
    yearsAtCompany: '',
    businessTravel: '',
    education: '',
    educationField: '',
    jobLevel: '',
    maritalStatus: '',
    numCompaniesWorked: '',
    performanceRating: '',
    totalWorkingYears: '',
    trainingTimesLastYear: '',
    workLifeBalance: '',
    yearsInCurrentRole: '',
    yearsSinceLastPromotion: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const newEmployee: Employee = {
      id: Date.now().toString(),
      age: parseInt(formData.age),
      attrition: false,
      department: formData.department,
      gender: formData.gender,
      jobRole: formData.jobRole,
      monthlyIncome: parseFloat(formData.monthlyIncome),
      yearsAtCompany: parseInt(formData.yearsAtCompany),
      businessTravel: formData.businessTravel,
      education: parseInt(formData.education),
      educationField: formData.educationField,
      jobLevel: parseInt(formData.jobLevel),
      maritalStatus: formData.maritalStatus,
      numCompaniesWorked: parseInt(formData.numCompaniesWorked),
      performanceRating: parseInt(formData.performanceRating),
      totalWorkingYears: parseInt(formData.totalWorkingYears),
      trainingTimesLastYear: parseInt(formData.trainingTimesLastYear),
      workLifeBalance: parseInt(formData.workLifeBalance),
      yearsInCurrentRole: parseInt(formData.yearsInCurrentRole),
      yearsSinceLastPromotion: parseInt(formData.yearsSinceLastPromotion)
    };

    console.log('New employee:', newEmployee);
    navigate('/');
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    setFormData(prev => ({
      ...prev,
      [e.target.name]: e.target.value
    }));
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-8">Add New Employee</h1>
      
      <form onSubmit={handleSubmit} className="max-w-2xl bg-white p-6 rounded-lg shadow-md">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label className="block text-sm font-medium text-gray-700">Age</label>
            <input
              type="number"
              name="age"
              value={formData.age}
              onChange={handleChange}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700">Department</label>
            <select
              name="department"
              value={formData.department}
              onChange={handleChange}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
              required
            >
              <option value="">Select Department</option>
              {departments.map(dept => (
                <option key={dept} value={dept}>{dept}</option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700">Gender</label>
            <select
              name="gender"
              value={formData.gender}
              onChange={handleChange}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
              required
            >
              <option value="">Select Gender</option>
              <option value="Male">Male</option>
              <option value="Female">Female</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700">Job Role</label>
            <select
              name="jobRole"
              value={formData.jobRole}
              onChange={handleChange}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
              required
            >
              <option value="">Select Job Role</option>
              {jobRoles.map(role => (
                <option key={role} value={role}>{role}</option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700">Monthly Income</label>
            <input
              type="number"
              name="monthlyIncome"
              value={formData.monthlyIncome}
              onChange={handleChange}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700">Years at Company</label>
            <input
              type="number"
              name="yearsAtCompany"
              value={formData.yearsAtCompany}
              onChange={handleChange}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700">Business Travel</label>
            <select
              name="businessTravel"
              value={formData.businessTravel}
              onChange={handleChange}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
              required
            >
              <option value="">Select Business Travel</option>
              {businessTravelOptions.map(option => (
                <option key={option} value={option}>{option}</option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700">Education Level (1-5)</label>
            <input
              type="number"
              name="education"
              value={formData.education}
              onChange={handleChange}
              min="1"
              max="5"
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700">Education Field</label>
            <select
              name="educationField"
              value={formData.educationField}
              onChange={handleChange}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
              required
            >
              <option value="">Select Education Field</option>
              {educationFields.map(field => (
                <option key={field} value={field}>{field}</option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700">Marital Status</label>
            <select
              name="maritalStatus"
              value={formData.maritalStatus}
              onChange={handleChange}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
              required
            >
              <option value="">Select Marital Status</option>
              {maritalStatusOptions.map(status => (
                <option key={status} value={status}>{status}</option>
              ))}
            </select>
          </div>
        </div>

        <div className="mt-6">
          <button
            type="submit"
            className="w-full bg-indigo-600 text-white py-2 px-4 rounded-md hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2"
          >
            Add Employee
          </button>
        </div>
      </form>
    </div>
  );
};

export default AddEmployee;