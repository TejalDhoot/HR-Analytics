import React, { useState, useMemo } from 'react';
import DashboardMetrics from '../components/DashboardMetrics';
import DashboardCharts from '../components/DashboardCharts';
import { Employee } from '../types';
import { sampleEmployees } from '../data/sampleData';

const Dashboard = () => {
  const [employees] = useState<Employee[]>(sampleEmployees);
  const [selectedDepartments, setSelectedDepartments] = useState<string[]>([]);
  const [selectedGenders, setSelectedGenders] = useState<string[]>([]);

  const filteredEmployees = useMemo(() => {
    return employees.filter(emp => {
      const deptMatch = selectedDepartments.length === 0 || selectedDepartments.includes(emp.department);
      const genderMatch = selectedGenders.length === 0 || selectedGenders.includes(emp.gender);
      return deptMatch && genderMatch;
    });
  }, [employees, selectedDepartments, selectedGenders]);

  const metrics = useMemo(() => ({
    totalEmployees: filteredEmployees.length,
    attritionRate: (filteredEmployees.filter(emp => emp.attrition).length / filteredEmployees.length) * 100,
    averageIncome: filteredEmployees.reduce((acc, emp) => acc + emp.monthlyIncome, 0) / filteredEmployees.length
  }), [filteredEmployees]);

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-8">HR Analytics Dashboard</h1>
      
      <div className="mb-8">
        <h2 className="text-xl font-semibold mb-4">Filters</h2>
        <div className="flex gap-4">
          <select
            multiple
            className="form-multiselect rounded-md"
            onChange={(e) => setSelectedDepartments(Array.from(e.target.selectedOptions, option => option.value))}
          >
            {Array.from(new Set(employees.map(emp => emp.department))).map(dept => (
              <option key={dept} value={dept}>{dept}</option>
            ))}
          </select>
          
          <select
            multiple
            className="form-multiselect rounded-md"
            onChange={(e) => setSelectedGenders(Array.from(e.target.selectedOptions, option => option.value))}
          >
            {Array.from(new Set(employees.map(emp => emp.gender))).map(gender => (
              <option key={gender} value={gender}>{gender}</option>
            ))}
          </select>
        </div>
      </div>

      <DashboardMetrics metrics={metrics} />
      <DashboardCharts employees={filteredEmployees} />
    </div>
  );
};

export default Dashboard;